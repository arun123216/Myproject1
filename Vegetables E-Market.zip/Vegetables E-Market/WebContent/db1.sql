drop table users;
drop sequence users_seq;
 create sequence users_seq increment by 1;
 CREATE SEQUENCE users_seq
INCREMENT BY 1
START WITH 100;

create table users(
id number(10) primary key,
name varchar2(30) not null,
email varchar2(50) not null,
password varchar2(20) not null
);

drop table app_admin;
create table app_admin(
  id number(10),
  admin_id varchar2(20),
  admin_password varchar2(20)
  );
  
  insert into app_admin values(1,'arun','123216');


drop table add_product;

 CREATE SEQUENCE add_product_seq
INCREMENT BY 1
START WITH 10;

  create table add_product(
  id number(10) primary key,
  p_name varchar2(30) not null,
  price number(10,2) not null,
  quantity number(10) not null,
  category varchar2(10) not null,
  file_data blob
   );

alter table add_product add  file_name varchar2(100);
 
 select * from users u1 inner join add_product u2 on u1.id=u2.id;
 
 select u1.id,u1.name,u1.email,u2.id,u2.p_name,u2.price from users u1 left join add_product u2 on u1.id=u2.id;
 
 
 drop table pro_order;

 CREATE SEQUENCE pro_order_seq
INCREMENT BY 1
START WITH 50;

  create table pro_order(
  order_id number(10),
  address varchar2(50),
  city varchar2(10),
  states varchar2(10),
   zip number(10),
   cardholder_name number(20),
   card_number number(20),
   exp_month number(30),
   exp_year number(30),
   card_cvv number(20)
  ); 
  
  
  
