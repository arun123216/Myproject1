package sis.com.controller;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

//import sis.com.bo.User;
import sis.com.bo.Admin;

/**
 * Servlet implementation class LoginServlet
 */
public class AdminLoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		RequestDispatcher rd = request.getRequestDispatcher("admin.jsp");
		rd.forward(request, response);
		
		
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String loginId = request.getParameter("admin_id"); 
		String loginPassword = request.getParameter("admin_password"); 
		

		  Admin loginAdmin  = null;
		  //validate in dabase
		Connection con = null;
		Statement stmt = null;
		ResultSet rs = null;
				 //declare required type 
			String user="system";
			String password="root";//if you password id diff change it
			String url  = "jdbc:oracle:thin:@localhost:1521:XE";	
		 
			StringBuilder errorCode = new StringBuilder("");
			 try{
				Class.forName("oracle.jdbc.driver.OracleDriver");
				con  = DriverManager.getConnection(url,user,password);
				stmt  = con.createStatement();
				 
				String sql="select  * from  app_admin where admin_id='"+loginId+"' and admin_password='"+loginPassword+"'" ; 
		     	 rs  =  stmt.executeQuery(sql);
				if( rs.next() ){
			          long id  =rs.getLong("id");
					  
					  loginAdmin= new Admin();
					  loginAdmin.setId(id);
					  
					  loginAdmin.setLoginId(loginId);
					  loginAdmin.setLoginPassword(loginPassword);
//					  loginUser.setRole(role);
				}
				
			 }catch(ClassNotFoundException e){
			   errorCode.append("Driver Not Loaded....." + e.getMessage());
			 }catch(SQLException e){
			   errorCode.append("DB ERROR : " +e.getMessage());
			   e.printStackTrace();
			 }catch(Exception e){
			   errorCode.append("Other ERROR " + e.getMessage());
			 }finally{
			     //release resoucer
			      if(con!=null){
				          try{
						     con.close();  //#5 close connection 
							}catch(SQLException e){
								errorCode.append("DB Con CLosing ERROR : "+ e.getMessage());
						  }//catch
				  }//if
			 }//finally
		  
		  
		//if user found means login successfull
			 //if user not found invalid user/password 

			 if(loginAdmin!=null){
				 //if user found means login successfull
			    //create session object
				 HttpSession session = request.getSession();
				//add required attribute for next service
				 session.setAttribute("admin", loginAdmin);
				 //then send to main service page
				 //project page 
				 /*String projectPath = getServletContext().getContextPath();
				 response.sendRedirect(projectPath);*/
				 request.getRequestDispatcher("home1.jsp").forward(request, response);
			 }else{
				 errorCode.append("invalide login id or password");
				 
				 request.setAttribute("loginError", errorCode.toString());
				 request.getRequestDispatcher("admin.jsp").forward(request, response);
					
			 }
		
		
	}

}
