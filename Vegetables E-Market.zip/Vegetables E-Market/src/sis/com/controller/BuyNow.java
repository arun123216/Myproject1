package sis.com.controller;

import java.io.IOException;
import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;




import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import sis.com.bo.Product;

/**
 * Servlet implementation class BuyNow
 */
public class BuyNow extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    
protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		StringBuilder errorCode = new StringBuilder();
		String updateMessge="";
		String  productIdStr= request.getParameter("id");

		long productId  = Long.parseLong(productIdStr);
		
		//id base 
		//db fetch record
		//create pojo  product obj
		//send to view 
		Product product = null;
		  //jdbc   db logic
			Connection con = null;
			PreparedStatement pstmt  =null;
			ResultSet rs =null;
			//declare required type 
			String user="system";
			String password="root";
			String url  = "jdbc:oracle:thin:@localhost:1521:XE";	
		try{
				Class.forName("oracle.jdbc.driver.OracleDriver");
				con  = DriverManager.getConnection(url,user,password);
				String sql="select * from add_product where id=?" ; 
				pstmt  = con.prepareStatement(sql);
				pstmt.setLong(1,productId);
				//******************************************
				rs  =  pstmt.executeQuery();
				if( rs.next() ){
			          long id  =rs.getLong("id");
					  String p_name  = rs.getString("p_name");
					 
					  float price  =rs.getFloat("price");
					 int quantity=rs.getInt("quantity");
					 String category=rs.getString("category");
					 
							 
					  product  = new Product();
					  product.setId(id);
					  product.setP_name(p_name);
					  product.setPrice(price);
					  product.setQuantity(quantity);
					  product.setCategory(category);
					  
					 
					   
				}//end if
				
			 }catch(ClassNotFoundException e){
			   errorCode.append("<h1 style='color:red'>Driver Not Loaded....." + e.getMessage()+"</h1>");
			 }catch(SQLException e){
			   errorCode.append("<h1 style='color:red'>DB ERROR : " +e.getMessage()+"</h1>");
			   e.printStackTrace();
			 }catch(Exception e){
			   errorCode.append("<h1 style='color:red'>Other ERROR " + e.getMessage()+"</h1>");
			 }finally{
			     //release resoucer
			      if(con!=null){
				          try{
						     con.close();  //#5 close connection 
							}catch(SQLException e){
								 errorCode.append("DB Con CLosing ERROR : "+ e.getMessage());
						  }//catch
				  }//if
			 }//finally

		//jdbc done
		request.setAttribute("errorCode", errorCode.toString());
	    request.setAttribute("product",product);
		request.getRequestDispatcher("buy_now1.jsp").forward(request, response);
		
	}


}
