package sis.com.controller;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class DbDownloadController1
 */
public class DbDownloadController1 extends HttpServlet {
	private static final long serialVersionUID = 1L;

	 
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		 //get param
		  //read data from db
		  //write binary into browser
		//String stuIdStr  = request.getParameter("stu_id");
		//Long stuId  = Long.parseLong(stuIdStr);
		String  productIdStr= request.getParameter("id");

		long productId  = Long.parseLong(productIdStr);
		
		StringBuilder errorMsg = new StringBuilder();
		Connection con = null;
		PreparedStatement pstmt  =null;
		ResultSet rs  = null;
		//declare required type 
		String dbuser="system";
		String dbpassword="root";
		String url  = "jdbc:oracle:thin:@localhost:1521:XE";	

		try{
			Class.forName("oracle.jdbc.driver.OracleDriver");
			con  = DriverManager.getConnection(url,dbuser,dbpassword);
			String sql="select * from add_product where id=?" ; 
			pstmt  = con.prepareStatement(sql);
			pstmt.setLong(1,productId);
			rs  = pstmt.executeQuery();
			if(rs.next()){
				//long id = rs.getLong("id");
				//String name =rs.getString("name");
				String fileName  =rs.getString("file_name");
				InputStream dataIS = rs.getBinaryStream("file_data");
				//write 
				ServletOutputStream sos = response.getOutputStream();
				//most important
				response.setContentType("application/octet-stream");
				response.setHeader("Content-Disposition","attachment; filename=\""+fileName+"\"");
				try {
					byte [] buff = new byte[1024*1024];
					int totalReadSize;
					while((totalReadSize =dataIS.read(buff))!=-1){
						sos.write(buff, 0, totalReadSize);
					}
					sos.close();
				} catch (Exception e) {
					// TODO: handle exception
				}finally{
					if(dataIS!=null){
						dataIS.close();
					}
				}

				//<a href="dbdownload1?stu_id=<%=id%>"><%=name%>::  <%=fileName%> donwload</a><br>
			}//if record found end 

		}catch(ClassNotFoundException e){
			errorMsg.append("<h1 style='color:red'>Driver Not Loaded....." + e.getMessage()+"</h1>");
		}catch(SQLException e){
			errorMsg.append("<h1 style='color:red'>DB ERROR : " +e.getMessage()+"</h1>");
		  e.printStackTrace();
		}catch(Exception e){
			errorMsg.append("<h1 style='color:red'>Other ERROR " + e.getMessage()+"</h1>");
		}finally{
		    //release resoucer
		     if(con!=null){
			          try{
					     con.close();  
						}catch(SQLException e){
							errorMsg.append("DB Con CLosing ERROR : "+ e.getMessage());
					  }//catch
			  }//if
		}//finally 
		
		response.sendRedirect("showallproduct?add_msg="+errorMsg);
		}
		 
		
		
		
		
		
		
	}


