package sis.com.controller;

import java.io.IOException;
import sis.com.util.EmailPasswordUtil;
import javax.mail.*;
	import javax.mail.internet.*;
	 import java.util.*;
	 import java.util.Date;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class SendMsg
 */

public class SendMsg extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
   
   protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		
		StringBuilder errorCode = new StringBuilder();
		
		String  fname= request.getParameter("firstname");
		
		String   clientUserEmail= request.getParameter("email");
		String  address= request.getParameter("address");
		String  city= request.getParameter("city");
		String  state= request.getParameter("state");
		Date d1=new Date();
		
		String addMsg="";
		
		
		
		//IF ERROR send udpate 
		if(errorCode.length()>0){
			request.setAttribute("errorCode", errorCode.toString());
			request.getRequestDispatcher("buy_now.jsp").forward(request, response);
			return;
		}
		
		
		

		
		//first time get from parameter 
		
	
		 //_______________________________________________________
		 //email code start
		  //TODO 
		  //NOTE senderEmailId  less secure =on  MUST
		  final String senderEmailId = "arunsariya@gmail.com";
		final String senderPassword = "arunnitrr";
		//final String senderPassword = EmailPasswordUtil.getPassword();

		//gmail email server details 
		Properties props = new Properties();
		//set key and value 
		props.put("mail.smtp.auth", "true");
		props.put("mail.smtp.starttls.enable", "true");
		props.put("mail.smtp.host", "smtp.gmail.com");
		props.put("mail.smtp.port", "587");


		//create email session object
		System.out.println("order starting .....");
		System.out.println("order Date and time is ....."+d1);
		Session email_session = Session.getInstance(props,
		  new javax.mail.Authenticator() {
			protected PasswordAuthentication getPasswordAuthentication() {
				return new PasswordAuthentication(senderEmailId, senderPassword);
				//return new PasswordAuthentication(arunsariya@gmail.com , arun123216);
			}
		  });
		  

		try {
			System.out.println("message sending");
		    //create messege object 
			Message message = new MimeMessage(email_session);
			
			message.setFrom(new InternetAddress(senderEmailId));
			
			String receiverEmailList=clientUserEmail;
			
			message.setRecipients(Message.RecipientType.TO,InternetAddress.parse(receiverEmailList));
			
			String subject= "Successfull Purchesed your iteam";
			message.setSubject(subject);
				
			String dataText="Dear"+fname+"your address is"+address+city+state+"order date and time is"+d1;
			message.setText(dataText);
			//send email 
			Transport.send(message);
			System.out.println("message sent ");
		} catch (MessagingException e) {
			//throw new RuntimeException(e);
			System.out.print(e.getMessage());
			e.printStackTrace();
		}
		  
		  
		 //email code END 
		 //_______________________________________________________
		//session.setAttribute("userEmail", clientUserEmail);
		
		 addMsg = " You Are Successfully orderd for This iteam ";
		 
		 System.out.println("step1"+clientUserEmail);
		 request.setAttribute("errorCode", errorCode.toString());
		 request.setAttribute("add_msg", addMsg.toString());
		 //response.sendRedirect("buynow?add_msg="+addMsg);
		request.getRequestDispatcher("buy_now.jsp").forward(request, response);
	
		
		
   }
}
