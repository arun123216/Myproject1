package sis.com.controller;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import sis.com.bo.Product;

/**
 * Servlet implementation class ShowHome
 */
public class ShowHome extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
   

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	
		protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		    List<Product>productList1  = new ArrayList<Product>();
			
		    StringBuilder errorCode = new StringBuilder();
			  //jdbc   db logic
				Connection con = null;
				Statement stmt  =null;
				ResultSet rs =null;
				//declare required type 
				String user="system";
				String password="root";
				String url  = "jdbc:oracle:thin:@localhost:1521:XE";	
			try{
					Class.forName("oracle.jdbc.driver.OracleDriver");
					con  = DriverManager.getConnection(url,user,password);
					stmt  = con.createStatement();
					//******************************************
					String sql="select * from add_product order by id desc" ; 
					rs  =  stmt.executeQuery(sql);
					while( rs.next() ){
				          long id  =rs.getLong("id");
						  String p_name  = rs.getString("p_name");
						  
						  float price  =rs.getFloat("price");
						  int quantity  =rs.getInt("quantity");
						  String category  = rs.getString("category");
						
							

						  
						  Product pro1  = new Product();
						  pro1.setId(id);
						  pro1.setP_name(p_name);
						  pro1.setPrice(price);
						  pro1.setQuantity(quantity);
						  pro1.setCategory(category);
						  
						  //pro.setRecordCreated(created);
						  productList1.add(pro1);
					}//end while 
					
				 }catch(ClassNotFoundException e){
				   errorCode.append("<h1 style='color:red'>Driver Not Loaded....." + e.getMessage()+"</h1>");
				 }catch(SQLException e){
				   errorCode.append("<h1 style='color:red'>DB ERROR : " +e.getMessage()+"</h1>");
				   e.printStackTrace();
				 }catch(Exception e){
				   errorCode.append("<h1 style='color:red'>Other ERROR " + e.getMessage()+"</h1>");
				 }finally{
				     //release resoucer
				      if(con!=null){
					          try{
							     con.close();  //#5 close connection 
								}catch(SQLException e){
									 errorCode.append("DB Con CLosing ERROR : "+ e.getMessage());
							  }//catch
					  }//if
				 }//finally

			//jdbc done
			//add attribute for presentation /view
			request.setAttribute("errorCode",errorCode.toString());
			request.setAttribute("allproduct1", productList1);
//			request.getRequestDispatcher("show_all_product.jsp").forward(request, response);
			//request.getRequestDispatcher("home.jsp").forward(request, response);
		     request.getRequestDispatcher("home.jsp").forward(request, response);
			
		}

		
	}


