package sis.com.util;

public class EmailPasswordUtil {
public static String getPassword(){
	return "your email sender password";
}
}
